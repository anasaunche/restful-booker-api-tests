# Upwork portfolio – paste-ready guide

All three pieces use the public **Restful-Booker** practice API, so there's nothing confidential in them. Every bug was reproduced against the live API on 2026-10-30.

## Step 0 – Put the Postman collection on GitHub (10 min, do this first)

1. On GitHub, create a public repo called `restful-booker-api-tests`.
2. Upload everything inside the `postman-collection/` folder, including the hidden `.github/workflows/api-tests.yml` file (open the folder, drag all files in, and make sure `.github` is included).
3. Go to the **Actions** tab → *API tests* → **Run workflow**. A green run gives you a CI badge and HTML reports.
4. Optional: in Postman, import both JSON files, select the *Restful-Booker* environment, then run the collection once. Folders 00–03 should pass and the 8 assertions in folder 04 should fail (that's intended: they're the documented bugs). Take a screenshot of the Runner results: it makes a good second image for item 1.

## How to add each item

Upwork → Profile → **Portfolio** → **+** (Add project). For each item:
1. **Project title** and **Your role**: paste from below.
2. **Project description**: paste from below (each one is under 600 characters).
3. **Skills and deliverables**: add the listed skills.
4. **Content**: upload the cover PNG first (it's the thumbnail), then add the PDF or the page PNGs, then the GitHub link where listed.
5. Preview → **Publish**.

---

## 1) Postman collection

**Title:** API Test Automation with Postman & CI – Booking REST API
**Role:** QA Automation Engineer (sole tester)
**Content:** `covers/cover-postman.png` → (optional) Postman Runner screenshot → link to your GitHub repo

**Description:**
> Built an automated API test suite in Postman for a hotel booking REST API: 20 requests and 50 assertions covering a chained create → read → search → update → delete flow, JSON-schema validation, token-based auth and security checks, and negative/boundary tests. Runs in GitHub Actions with Newman: regression tests gate the build, known defects are tracked in a separate job, and HTML reports are saved on every run. The suite found 7 defects, including data corruption and unhandled 500 errors.

**Skills:** API Testing · Postman · Test Automation · REST API · Quality Assurance

---

## 2) Test plan

**Title:** Risk-Based Test Plan for a Booking REST API
**Role:** QA Engineer – test strategy & documentation
**Content:** `covers/cover-testplan.png` → `test-plan/Restful-Booker_Test-Plan.pdf` (if the PDF won't upload, add `test-plan/pages/*.png` instead)

**Description:**
> Wrote a complete test plan for a hotel booking API: objectives, scope, risk analysis, approach (functional, negative, security, contract, exploratory), 21 prioritised test cases, test data strategy, entry/exit criteria, defect workflow, schedule and an execution summary with recommendations. The kind of document I deliver at the start of a project so the client knows what will be tested, what won't, and when we're done.

**Skills:** Test Plan · Software Testing · Quality Assurance · Test Case Design · Manual Testing

---

## 3) EN/ES bug report pack

**Title:** Bilingual (EN/ES) Bug Report Pack – REST API Defects
**Role:** QA Engineer – bug reporting in English & Spanish
**Content:** `covers/cover-bugpack.png` → `bug-report-pack/Restful-Booker_Bug-Reports_EN-ES.pdf` (or `bug-report-pack/pages/*.png`)

**Description:**
> Seven real defects found in a public booking API, each documented side by side in English and Spanish: severity, priority, steps to reproduce, expected vs. actual result, business impact and request/response evidence. Includes 3 high-severity issues (e.g. invalid dates stored as "0NaN-aN-aN"). Each bug links to a failing test in my Postman suite. Clear reports developers can act on immediately, in either language.

**Skills:** Bug Reporting · Spanish · English · API Testing · Quality Assurance

---

## Tips

- Put these three at the top of your portfolio, right after the Playwright suite.
- In proposals, link the bug pack for EN/ES or LATAM clients and the Postman item for API jobs.
- Before publishing, swap your GitHub username into the repo link and check the README author line.
